new Slider(document.querySelector('.slider'));
