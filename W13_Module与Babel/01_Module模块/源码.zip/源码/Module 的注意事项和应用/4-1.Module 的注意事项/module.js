// console.log(this);

// if (typeof this !== 'undefined') {
//   throw new Error('请使用模块的方式加载');
// }

export const age = 18;
