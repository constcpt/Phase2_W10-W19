// base
export const ELEMENT_NODE = 1;
export const SLIDER_ANIMATION_CLASSNAME = 'slider-animation';

// keyboard
export const LEFT_KEYCODE = 37;
export const RIGHT_KEYCODE = 39;
