import Slider from './slider.js';

new Slider(document.querySelector('.slider'));
