const age = 18;
// const sex = 'male';
// console.log(age);

// export default age;
// export default 20;
// export default {};

// const fn = () => {};
// export default fn;
// export default function () {}

export default class {}

// 一个模块只能有一个 export default
// export default sex;
