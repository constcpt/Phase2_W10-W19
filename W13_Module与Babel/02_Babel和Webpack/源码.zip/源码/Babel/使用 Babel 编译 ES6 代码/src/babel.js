let name = 'Alex';
const age = 18;
const add = (x, y) => x + y;
new Promise((resolve, reject) => {
  resolve('成功');
});
Array.from([1, 2]);
class Person {}
import './index.js';
