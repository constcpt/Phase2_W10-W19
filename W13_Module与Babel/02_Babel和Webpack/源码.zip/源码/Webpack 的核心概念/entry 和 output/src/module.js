export default 18;
console.log('module.js');
