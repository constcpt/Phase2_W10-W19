import age from './module.js';

console.log('index.js', age);
